#include "Astar_searcher.h"

using namespace std;
using namespace Eigen;

void AstarPathFinder::initGridMap(double _resolution, Vector3d global_xyz_l, Vector3d global_xyz_u, int max_x_id, int max_y_id, int max_z_id)
{   
    gl_xl = global_xyz_l(0);
    gl_yl = global_xyz_l(1);
    gl_zl = global_xyz_l(2);
    ROS_INFO("gl_zl = %.2f",gl_zl);

    gl_xu = global_xyz_u(0);
    gl_yu = global_xyz_u(1);
    gl_zu = global_xyz_u(2);
    
    GLX_SIZE = max_x_id;
    GLY_SIZE = max_y_id;
    GLZ_SIZE = max_z_id;
    ROS_INFO("GLZ_SIZE = %d",GLZ_SIZE);
    GLYZ_SIZE  = GLY_SIZE * GLZ_SIZE;
    GLXYZ_SIZE = GLX_SIZE * GLYZ_SIZE;

    resolution = _resolution;
    inv_resolution = 1.0 / _resolution;    

    data = new uint8_t[GLXYZ_SIZE];//data是一个全局数组，也是指针 data中存放了整个3D地图的索引数据？data是一个指向该内存区域的指针 同时data也是数组名
    memset(data, 0, GLXYZ_SIZE * sizeof(uint8_t));// 复制字符 0（int）（一个无符号字符）到指针data指向的数组的前GLXYZ_SIZE个字符(即先把存放3维地图的全部区域初始化)
    
    GridNodeMap = new GridNodePtr ** [GLX_SIZE];
    for(int i = 0; i < GLX_SIZE; i++){
        GridNodeMap[i] = new GridNodePtr * [GLY_SIZE];
        for(int j = 0; j < GLY_SIZE; j++){
            GridNodeMap[i][j] = new GridNodePtr [GLZ_SIZE];
            for( int k = 0; k < GLZ_SIZE;k++){
                Vector3i tmpIdx(i,j,k);
                Vector3d pos = gridIndex2coord(tmpIdx);
                GridNodeMap[i][j][k] = new GridNode(tmpIdx, pos);//分配了一个 GridNode 类型的对象，并传递了两个参数 tmpIdx 和 pos 给该对象的构造函数，以初始化该对象
            }
        }
    }
}

void AstarPathFinder::resetGrid(GridNodePtr ptr)
{
    ptr->id = 0;
    ptr->cameFrom = NULL;
    ptr->gScore = inf;
    ptr->fScore = inf;
}

void AstarPathFinder::resetUsedGrids()
{   
    for(int i=0; i < GLX_SIZE ; i++)
        for(int j=0; j < GLY_SIZE ; j++)
            for(int k=0; k < GLZ_SIZE ; k++)
                resetGrid(GridNodeMap[i][j][k]);
}

void AstarPathFinder::setObs(const double coord_x, const double coord_y, const double coord_z)
{   
    if( coord_x < gl_xl  || coord_y < gl_yl  || coord_z <  gl_zl || 
        coord_x >= gl_xu || coord_y >= gl_yu || coord_z >= gl_zu )
        return;

    int idx_x = static_cast<int>( (coord_x - gl_xl) * inv_resolution);
    int idx_y = static_cast<int>( (coord_y - gl_yl) * inv_resolution);
    int idx_z = static_cast<int>( (coord_z - gl_zl) * inv_resolution);      

    data[idx_x * GLYZ_SIZE + idx_y * GLZ_SIZE + idx_z] = 1;//将这个区域的内容设置为1，代表存在障碍
}

vector<Vector3d> AstarPathFinder::getVisitedNodes()
{   
    vector<Vector3d> visited_nodes;
    for(int i = 0; i < GLX_SIZE; i++)
        for(int j = 0; j < GLY_SIZE; j++)
            for(int k = 0; k < GLZ_SIZE; k++){   
                //if(GridNodeMap[i][j][k]->id != 0) // visualize all nodes in open and close list
                if(GridNodeMap[i][j][k]->id == -1)  // visualize nodes in close list only
                    visited_nodes.push_back(GridNodeMap[i][j][k]->coord);
            }

    ROS_WARN("visited_nodes size : %d", visited_nodes.size());
    return visited_nodes;
}

Vector3d AstarPathFinder::gridIndex2coord(const Vector3i & index) 
{
    Vector3d pt;

    pt(0) = ((double)index(0) + 0.5) * resolution + gl_xl;
    pt(1) = ((double)index(1) + 0.5) * resolution + gl_yl;
    pt(2) = ((double)index(2) + 0.5) * resolution + gl_zl;

    return pt;
}

Vector3i AstarPathFinder::coord2gridIndex(const Vector3d & pt) 
{
    Vector3i idx;
    idx <<  min( max( int( (pt(0) - gl_xl) * inv_resolution), 0), GLX_SIZE - 1),
            min( max( int( (pt(1) - gl_yl) * inv_resolution), 0), GLY_SIZE - 1),
            min( max( int( (pt(2) - gl_zl) * inv_resolution), 0), GLZ_SIZE - 1); 
            //为了确保索引值不超出网格地图的范围，使用 min 和 max 函数将索引值限制在 0 到 GLX/Y/Z_SIZE-1 的范围内                 
  
    return idx;
}

Eigen::Vector3d AstarPathFinder::coordRounding(const Eigen::Vector3d & coord)
{
    return gridIndex2coord(coord2gridIndex(coord));
}

//判断是否有障碍物
inline bool AstarPathFinder::isOccupied(const Eigen::Vector3i & index) const
{
    return isOccupied(index(0), index(1), index(2));
}

//判断是否无障碍物
inline bool AstarPathFinder::isFree(const Eigen::Vector3i & index) const
{
    return isFree(index(0), index(1), index(2));
}

inline bool AstarPathFinder::isOccupied(const int & idx_x, const int & idx_y, const int & idx_z) const 
{
    return  (idx_x >= 0 && idx_x < GLX_SIZE && idx_y >= 0 && idx_y < GLY_SIZE && idx_z >= 0 && idx_z < GLZ_SIZE && 
            (data[idx_x * GLYZ_SIZE + idx_y * GLZ_SIZE + idx_z] == 1));
}

inline bool AstarPathFinder::isFree(const int & idx_x, const int & idx_y, const int & idx_z) const 
{
    return (idx_x >= 0 && idx_x < GLX_SIZE && idx_y >= 0 && idx_y < GLY_SIZE && idx_z >= 0 && idx_z < GLZ_SIZE && 
           (data[idx_x * GLYZ_SIZE + idx_y * GLZ_SIZE + idx_z] < 1));
}

inline void AstarPathFinder::AstarGetSucc(GridNodePtr currentPtr, vector<GridNodePtr> & neighborPtrSets, vector<double> & edgeCostSets)
{   
    neighborPtrSets.clear();
    edgeCostSets.clear();
    /*
    *
    STEP 4: finish AstarPathFinder::AstarGetSucc yourself 
    please write your code below
    *
    *
    */
    //将currentPtr所有邻居节点写入vector<GridNodePtr> neighborPtrSets;计算对应的vector<double> edgeCostSets;
    if(currentPtr == nullptr)
        ROS_INFO ("Error: Current pointer is null!");

    Vector3i idx = currentPtr->index;
    int current_x = idx[0];
    int current_y = idx[1];
    int current_z = idx[2];
    for(int i = (current_x-1);i <= (current_x + 1); i++){
        for(int j = (current_y - 1);j <= (current_y + 1); j++){
            for(int k = (current_z - 1);k <= (current_z + 1); k++){
                //currentPtr不算入neighborPtrSets
                if(i == current_x && j ==current_y && k == current_z)
                {
                    //ROS_INFO("1111111111111111111");
                    continue;
                }
                //防止x,y,z索引越界
                if(i < 0 || i  > (GLX_SIZE - 1) || j < 0 || j > (GLY_SIZE - 1) || k < 0 || k > (GLZ_SIZE - 1))
                {
                    //ROS_INFO("22222222222222222222222");
                    continue;
                }
                //周围栅格若存在障碍物则跳过
                Vector3i tmpIdx(i,j,k);
                if(isOccupied(tmpIdx))
                {
                    //ROS_INFO("33333333333333333333");
                    continue;
                }
                //若存在closelist中
                if(GridNodeMap[i][j][k]->id == -1)
                {
                    //ROS_INFO("4444444444444444444444444");
                    continue;
                }
                neighborPtrSets.push_back(GridNodeMap[i][j][k]);    
                edgeCostSets.push_back(sqrt(pow(i-idx(0),2)+pow(j-idx(1),2)+pow(k-idx(2),2)));
                Vector3d test = gridIndex2coord(tmpIdx);
                GridNodeMap[i][j][k]->coord = test;
                //ROS_INFO("i = %d,j = %d,k = %d",i,j,k);  
            }
        }
    }
}

double AstarPathFinder::getHeu(GridNodePtr node1, GridNodePtr node2)
{
    /* 
    choose possible heuristic function you want
    Manhattan, Euclidean, Diagonal, or 0 (Dijkstra)
    Remember tie_breaker learned in lecture, add it here ?
    *
    *
    *
    STEP 1: finish the AstarPathFinder::getHeu , which is the heuristic function
    please write your code below
    *
    *
    */

   //尝试以欧几里得距离作为启发式函数
   double Heu;
   double x1,y1,z1;
   double x2,y2,z2;
   
   x1 = (double)node1->index[0];
   y1 = (double)node1->index[1];
   z1 = (double)node1->index[2];
   x2 = (double)node2->index[0];
   y2 = (double)node2->index[1];
   z2 = (double)node2->index[2];


   Heu = sqrt(pow(x1-x2, 2) + pow(y1-y2, 2) + pow(z1-z2, 2));
//    ROS_INFO("point1(%.2f,%.2f,%.2f),point2(%.2f,%.2f,%.2f),Heu = %.2f",x1,y1,z1,x2,y2,z2,Heu);

   return Heu;
}

void AstarPathFinder::AstarGraphSearch(Vector3d start_pt, Vector3d end_pt)
{   
    ROS_INFO("[node] start plan");
    ros::Time time_1 = ros::Time::now();    
    ROS_INFO("[node] success get time1");
    //index of start_point and end_point
    ROS_INFO("start_pt_z = %.2f",start_pt(2));
    Vector3i start_idx = coord2gridIndex(start_pt);
    Vector3i end_idx   = coord2gridIndex(end_pt);
    ROS_INFO("goal_idx(%d,%d,%d)",end_idx[0],end_idx[1],end_idx[2]);
    goalIdx = end_idx;

    //position of start_point and end_point
    start_pt = gridIndex2coord(start_idx);
    end_pt   = gridIndex2coord(end_idx);//这个步骤不是很理解，难道为了方便计算?好像并没有方便很多

    //Initialize the pointers of struct GridNode which represent start node and goal node
    GridNodePtr startPtr = new GridNode(start_idx, start_pt); //结构体指针建立
    GridNodePtr endPtr   = new GridNode(end_idx,   end_pt);

    //openSet is the open_list implemented through multimap in STL library
    openSet.clear();
    // currentPtr represents the node with lowest f(n) in the open_list
    GridNodePtr currentPtr  = NULL;//open_list中f（n）最小的节点指针为currentPtr
    GridNodePtr neighborPtr = NULL;//open_list中f（n）最小的节点相邻节点的结构体指针为neighborPtr（是否包括已浏览过的节点？）

    //put start node in open set
    startPtr -> gScore = 0;
    startPtr -> fScore = getHeu(startPtr,endPtr);   
    //STEP 1: finish the AstarPathFinder::getHeu , which is the heuristic function
    startPtr -> id = 1; 
    startPtr -> coord = start_pt;
    openSet.insert( make_pair(startPtr -> fScore, startPtr) );
    ROS_INFO("[node] evergreen");
    ROS_INFO("fScore = %.2f",startPtr -> fScore);
    /*
    *
    STEP 2 :  some else preparatory works which should be done before while loop
    please write your code below
    *
    *
    */
   //assign g（Xs）=0,and g(n) = infinite for all other nodes in the graph.
    vector<GridNodePtr> neighborPtrSets;
    vector<double> edgeCostSets;
    // this is the main loop
    while ( !openSet.empty() ){
        /*
        *
        *
        step 3: Remove the node with lowest cost function from open set to closed set
        please write your code below
        
        IMPORTANT NOTE!!!
        This part you should use the C++ STL: multimap, more details can be find in Homework description
        *
        *
        */
       //弹出一个代价最小的节点作为currentPtr加入close list
       currentPtr = openSet.begin()->second;//注意
       openSet.erase(openSet.begin());
       currentPtr->id = -1; //closeset
       ROS_INFO("currentPtr_idx(%d,%d,%d)",currentPtr->index[0],currentPtr->index[1],currentPtr->index[2]);

        // if the current node is the goal 
        if( currentPtr->index == goalIdx ){
            ros::Time time_2 = ros::Time::now();
            terminatePtr = currentPtr;
            ROS_INFO("Path finding111");
            ROS_WARN("[A*]{sucess}  Time in A*  is %f ms, path cost if %f m", (time_2 - time_1).toSec() * 1000.0, currentPtr->gScore * resolution );            
            return;
        }
        //get the succetion
        ROS_INFO("start count neighborcost and edgecost");
        AstarGetSucc(currentPtr, neighborPtrSets, edgeCostSets);  //STEP 4: finish AstarPathFinder::AstarGetSucc yourself

        /*
        *
        *
        STEP 5:  For all unexpanded neigbors "m" of node "n", please finish this for loop
        please write your code below
        *        
        */         
        for(int i = 0; i < (int)neighborPtrSets.size(); i++){
            /*
            *
            *
            Judge if the neigbors have been expanded
            please write your code below
            
            IMPORTANT NOTE!!!
            neighborPtrSets[i]->id = -1 : unexpanded 关列表
            neighborPtrSets[i]->id = 1 : expanded, equal to this node is in close set 开列表
            *        
            */
            ROS_INFO("neighborPtrSets[%d]->id = %d ",i,neighborPtrSets[i] -> id);
            if(neighborPtrSets[i] -> id == 0){ //discover a new node, which is not in the closed set and open set 不在开列表也不在关列表
                /*
                *
                *
                STEP 6:  As for a new node, do what you need do ,and then put neighbor in open set and record it
                please write your code below
                *        
                */
                //ROS_INFO("[node] neighborid = 0");
                neighborPtrSets[i]->id = 1;
                neighborPtrSets[i]->gScore = currentPtr->gScore +(double)edgeCostSets[i];
                neighborPtrSets[i]->fScore = neighborPtrSets[i]->gScore + getHeu(neighborPtrSets[i],endPtr);
                neighborPtrSets[i]->cameFrom = currentPtr;
                openSet.insert( make_pair(neighborPtrSets[i] -> fScore, neighborPtrSets[i]) );
                continue;
            }   
               /*
                *
                STEP 7:  As for a node in open set, update it , maintain the openset ,and then put neighbor in open set and record it
                please write your code below
                *        
                */
            if(neighborPtrSets[i] -> id == 1 )
            {
                //ROS_INFO("[node] neighborid = 1");
                //this node is in open set and need to judge if it needs to update, the "0" should be deleted when you are coding
                if((neighborPtrSets[i]->gScore )>( currentPtr->gScore +edgeCostSets[i]))
                { 
                    auto ptr = openSet.equal_range(neighborPtrSets[i]->fScore);
                    neighborPtrSets[i]->gScore = currentPtr->gScore + edgeCostSets[i];
                    neighborPtrSets[i]->fScore = neighborPtrSets[i]->gScore + getHeu(neighborPtrSets[i],endPtr);
                    neighborPtrSets[i]->cameFrom = currentPtr;
                    // if(ptr.first != end(openSet))
                    // {
                    //     for(auto iter = ptr.first; iter != ptr.second; ++iter)
                    //     {
                    //          ROS_INFO("test1");
                    //         if(iter->second->index == neighborPtrSets[i]->index)
                    //         {
                    //             ROS_INFO("test7");
                    //             //ROS_INFO("success compare and delete!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    //             openSet.erase(iter);
                    //             openSet.insert( make_pair(neighborPtrSets[i] -> fScore, neighborPtrSets[i]));
                    //             ROS_INFO("success insert?????????????????????????????????");
                    //         }
                    //         ROS_INFO("test2");
                    //     }
                    //     ROS_INFO("test3");
                    // }
                    ROS_INFO("test4");
                }
                ROS_INFO("test5");
                continue;
            }
            //this node is in closed set
            else{
                ROS_INFO("test6");
                continue;
            }
        }      
    }
    //if search fails
    ros::Time time_2 = ros::Time::now();
    ROS_INFO("get time_2");
    if((time_2 - time_1).toSec() > 0.1)
    ROS_WARN("Time consume in Astar path finding is %f", (time_2 - time_1).toSec() );
}


vector<Vector3d> AstarPathFinder::getPath() 
{   
    vector<Vector3d> path;
    vector<GridNodePtr> gridPath;
    GridNodePtr currentNodePtr = terminatePtr;
    /*
    *
    *
    STEP 8:  trace back from the curretnt nodePtr to get all nodes along the path
    please write your code below
    *      
    */
    while (currentNodePtr != nullptr) {
        gridPath.push_back(currentNodePtr);
        currentNodePtr = currentNodePtr->cameFrom;
    }
    for (auto ptr: gridPath) //遍历容器中所有的元素
        path.push_back(ptr->coord);
    reverse(path.begin(),path.end());

    return path;
}